package Shopping;

import java.util.ArrayList;

public class ShoppingRepository
{
public static ArrayList<Electronics> list1;
public static ArrayList<Furniture> list3;
public static ArrayList<Clothes> list4;

public static void Repo() 
{

list1 = new ArrayList<Electronics>();
//***************Creating Data For Electronics Items**************************************//	  
Electronics electronic1 = new Electronics();
electronic1.setId(1);
electronic1.setName("washing machine");
electronic1.setDecription("samsung b22 ");
electronic1.setPrice(10000);
list1.add(electronic1);

Electronics electronic2 = new Electronics();
electronic2.setId(2);
electronic2.setName("Television");
electronic2.setDecription("Sony Bravia");
electronic2.setPrice(150000);
list1.add(electronic2);


list3 = new ArrayList<Furniture>();
//***************Creating Data For Furniture Items**************************************//
Furniture furniture1 = new Furniture();
furniture1.setId(1);
furniture1.setName("Laptop Table");
furniture1.setDecription("Wooden");
furniture1.setPrice(7999);
list3.add(furniture1);

Furniture furniture2 = new Furniture();
furniture2.setId(2);
furniture2.setName("Chair");
furniture2.setDecription("Confortable");
furniture2.setPrice(559);
list3.add(furniture2);




list4 = new ArrayList<Clothes>();
//***************Creating Data For Clothes Items**************************************//
Clothes gadget1 = new Clothes();
gadget1.setId(1);
gadget1.setName("Shirt");
gadget1.setDecription("Cotton");
gadget1.setPrice(999);
list4.add(gadget1);

Clothes gadget2 = new Clothes();
gadget2.setId(2);
gadget2.setName("Pants");
gadget2.setDecription("Cotton");
gadget2.setPrice(1499);
list4.add(gadget2);

}

}