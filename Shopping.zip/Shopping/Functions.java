package Shopping;

import java.util.Scanner;

public class Functions extends ShoppingRepository
{
int Num;
int Quantity;
int Sum ;

ShoppingController con = new ShoppingController();
public  void viewElectronic()
{   
System.out.println(">>>>>ELECTRONICS MENU");
System.out.println("Item ID :  Brand Name :          Description      :     Price");
System.out.println();
for(Electronics elec:list1) 
{
System.out.println("  " +elec.getId()+"       :  "+elec.getName()+"          :  "+elec.getDecription()+"       :  "+elec.getPrice()+".00");
System.out.println();
}

System.out.println("Enter ID to Buy Product");
Scanner sc = new Scanner(System.in);
Num = sc.nextInt();
System.out.println("Enter Quantity");
Quantity = sc.nextInt();
for(Electronics elec:list1)
{
if(Num==elec.getId())
{
Sum = Sum+(elec.getPrice())*Quantity;
System.out.println("ADD To Cart!! Total Amount "+Sum);
}
}


}

public  void viewFurniture()
{   
System.out.println(">>>>>>FURNITURE MENU");
System.out.println("Item ID :  Brand Name :          Description      :     Price");
System.out.println();
for(Furniture ftr:list3) 
{
System.out.println("  " +ftr.getId()+"        "+ftr.getName()+"          :   "+ftr.getDecription()+"        :  "+ftr.getPrice()+".00");
System.out.println();
}
System.out.println("Enter ID to Buy Product");
Scanner sc = new Scanner(System.in);
Num = sc.nextInt();
System.out.println("Enter Quantity");
Quantity = sc.nextInt();
for(Furniture ftr :list3)
{
if(Num==ftr.getId())
{
Sum = Sum+(ftr.getPrice())*Quantity;
System.out.println("ADD To Cart!! Total Amount "+Sum);
}
}

}


public  void viewClothes()
{   
System.out.println(">>>>>>Clothes MENU");
System.out.println("Item ID :  Brand Name :          Description      :     Price");
System.out.println();
for(Clothes ch:list4) 
{
System.out.println("  " +ch.getId()+"        "+ch.getName()+"          :   "+ch.getDecription()+"        :  "+ch.getPrice()+".00");
System.out.println();
}
System.out.println("Enter ID to Buy Product");
Scanner sc = new Scanner(System.in);
Num = sc.nextInt();
System.out.println("Enter Quantity");
Quantity = sc.nextInt();
for(Clothes ch :list4)
{
if(Num==ch.getId())
{
Sum = Sum+(ch.getPrice())*Quantity;
System.out.println("ADD To Cart!! Total Amount "+Sum);
}
}

}

}
